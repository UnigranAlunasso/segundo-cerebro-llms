# Como publicar no GitHub e entregar na DIO

1. Confira a seção **Compartilhar** do Gemini Notebook e selecione **Qualquer pessoa com o link**; teste o endereço com outra conta Google.
2. Descompacte este pacote no computador.
3. Crie um repositório **público** no GitHub chamado `segundo-cerebro-llms` (sem adicionar outro README, pois este pacote já contém um).
4. Envie o `README.md`, a pasta `evidencias/` e a pasta `materiais/` **como arquivos e pastas**, não apenas o arquivo ZIP.
5. Abra o repositório no navegador e confirme que as imagens e o PDF abrem pelos links do README.
6. Copie a URL do repositório GitHub e entregue essa URL no desafio da DIO.

Não coloque senhas, tokens de acesso ou arquivos pessoais no repositório público.

**Observação:** os arquivos já foram preparados, mas o compartilhamento do Gemini Notebook e a criação do repositório devem ser feitos na conta do autor.
